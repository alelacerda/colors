import Foundation
import UIKit

class ColorData: ObservableObject{
    @Published var backgroundColor: UIColor = .white
    @Published var coolTitleColor: UIColor = .black
    @Published var coolSubtitleColor: UIColor = .gray
    @Published var cardColor: UIColor = .lightGray
    @Published var cardTitleColor: UIColor = .white
    @Published var coolTextTitleColor: UIColor = .black
    @Published var coolTextColor: UIColor = .black
    @Published var buttonColor: UIColor = .gray
    @Published var buttonTextColor: UIColor = .white
    
    @Published var colorType: InclusiveColor.BlindnessType = .normal
    
    @Published var redValue: CGFloat = 0
    @Published var greenValue: CGFloat = 0
    @Published var blueValue: CGFloat = 0
    
    func contrast(between color1: UIColor, and color2: UIColor) -> CGFloat {
        return UIColor.contrastRatio(between: color1, and: color2)
    }
    
}

extension UIColor {

    static func contrastRatio(between color1: UIColor, and color2: UIColor) -> CGFloat {

        let luminance1 = color1.luminance()
        let luminance2 = color2.luminance()

        let luminanceDarker = min(luminance1, luminance2)
        let luminanceLighter = max(luminance1, luminance2)

        return (luminanceLighter + 0.05) / (luminanceDarker + 0.05)
    }

    func contrastRatio(with color: UIColor) -> CGFloat {
        return UIColor.contrastRatio(between: self, and: color)
    }

    func luminance() -> CGFloat {

        let ciColor = CIColor(color: self)

        func adjust(colorComponent: CGFloat) -> CGFloat {
            return (colorComponent < 0.04045) ? (colorComponent / 12.92) : pow((colorComponent + 0.055) / 1.055, 2.4)
        }

        return 0.2126 * adjust(colorComponent: ciColor.red) + 0.7152 * adjust(colorComponent: ciColor.green) + 0.0722 * adjust(colorComponent: ciColor.blue)
    }
}

